commands.bindAll();
events.bindAll();

