global.resources = {};

