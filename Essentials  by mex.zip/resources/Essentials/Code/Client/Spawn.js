global.spawn = {};

spawn.despawnLocalPlayer = () =>
{
	localClient.despawnPlayer();
};

