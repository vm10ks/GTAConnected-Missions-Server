global.chat = {};

