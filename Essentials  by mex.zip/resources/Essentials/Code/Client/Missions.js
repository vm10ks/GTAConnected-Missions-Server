global.missions = {};

