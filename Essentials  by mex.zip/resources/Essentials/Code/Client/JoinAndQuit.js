global.joinQuit = {};

