addEventHandler('onResourceReady', events.bindAll);

