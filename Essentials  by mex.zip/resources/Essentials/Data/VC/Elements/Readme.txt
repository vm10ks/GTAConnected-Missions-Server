If you want to edit the XML file in a text editor, stop the server first.
Keep in mind that IDs will be changed when the server starts.